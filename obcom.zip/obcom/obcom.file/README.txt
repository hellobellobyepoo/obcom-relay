to use obcom, right-click "Obcom.wpf", or double click.

also make a shortcut if you would like.
